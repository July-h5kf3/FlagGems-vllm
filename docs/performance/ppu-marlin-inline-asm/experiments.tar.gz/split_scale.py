import ast,sys
from pathlib import Path
from gen import replace_body
src=Path(sys.argv[1]).read_text();root=Path(sys.argv[2])
for name in ('decode_int8_scaled_bf16','decode_fp8_scaled_bf16_normalized','decode_raw_int4_bf16','decode_raw_mxfp4_bf16','decode_int8_fragment_bf16'):
 n=next(n for n in ast.parse(src).body if getattr(n,'name',None)==name)
 op=n.body[-1].value
 ins=ast.literal_eval(op.args[0])
 if name in ('decode_int8_fragment_bf16','decode_int8_scaled_bf16','decode_fp8_scaled_bf16_normalized'):
    import re
    ins=re.sub(r'ppu.mul.rn.bf16x2 v0,v0,\$3;\s*ppu.mul.rn.bf16x2 v1,v1,\$4;', '',ins)
    if name=='decode_int8_fragment_bf16':
        output='a,b'; args='q';ty='(tl.uint32,tl.uint32)';constraints='=r,=r,r';pack=1
        result='return multiply_bf16_pairs(a,s0), multiply_bf16_pairs(b,s1)'
    else:
        output='value';args='q';ty='tl.bfloat16';constraints='=r,=r,r';pack=4
        result='return (value * scale).to(tl.bfloat16)'
 else:
    import re
    ins=re.sub(r'ppu.mul.rn.bf16x2 ([lh][01]),\1,\$[56];','',ins)
    output='lo,hi';args='b';ty='(tl.bfloat16,tl.bfloat16)';constraints='=r,=r,=r,=r,r';pack=4
    result='return (lo*scale).to(tl.bfloat16),(hi*scale).to(tl.bfloat16)'
 body=f'{output}=tl.inline_asm_elementwise({ins!r},{constraints!r},[{args}],dtype={ty},is_pure=True,pack={pack})\n'+result
 if name=='decode_int8_fragment_bf16':
    t=(root/'proposal.py').read_text();t=replace_body(t,name,body)
 else:t=replace_body(src,name,body)
 (root/('split_'+name+'.py')).write_text(t)
