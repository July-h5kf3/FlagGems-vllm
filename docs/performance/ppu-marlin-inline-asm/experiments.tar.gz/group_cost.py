"""Same tile, consumers, swizzle and launch for the complete group protocol and TLE copy."""
import json,statistics
from pathlib import Path
import torch,triton,triton.language as tl,triton.testing
from triton.experimental.tle import language as tle
from flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe import copy_w8_tile_async,commit_w8_tile,wait_w8_tile

@triton.jit
def move(X,Y,R:tl.constexpr,C:tl.constexpr,USE_TLE:tl.constexpr):
    base=tl.program_id(0)*R*C
    row=tl.arange(0,R)[:,None]
    col=tl.arange(0,C)[None,:]
    offsets=row*C+col
    buf=tle.gpu.alloc([R,C],tl.uint32,layout=None,scope=tle.gpu.smem,nv_mma_shared_layout=False)
    if USE_TLE:
        sector=offsets//(R*8)
        rot=offsets//8%R
        skew=((sector&1)<<1)|((sector>>1)&1)
        srcrow=(rot & ~3)|((rot-skew)&3)
        srccol=sector*8+((offsets%8)^(((srcrow//4)&1)*4))
        tle.gpu.copy(X+base+srcrow*C+srccol,buf,(R,C))
        tl.debug_barrier()
    else:
        addr=tle.gpu.local_ptr(buf,(0,0)).to(tl.int64).to(tl.int32)
        tok=tl.full((256,),0,tl.int32)
        tok=copy_w8_tile_async(addr,(X+base).to(tl.pointer_type(tl.uint8)),R,C*4,C*4,0,tok)
        tok=commit_w8_tile(tok)
        tok=wait_w8_tile(tok,False)
    target=tle.gpu.local_ptr(buf,(row+col*0,col+row*0))
    tl.store(Y+base+offsets,tl.load(target))

root=Path(__file__).parent;output=[]
for r,c in [(8,32),(16,32),(64,16),(64,32),(128,32)]:
 grid=(1024,)
 x=torch.arange(1024*r*c,device="cuda",dtype=torch.int32).view(torch.uint32)
 y=[torch.empty_like(x),torch.empty_like(x)]
 calls=[lambda j=j:move[grid](x,y[j],r,c,bool(j),num_warps=8,num_stages=1) for j in range(2)]
 compiled=[f() for f in calls]
 assert torch.equal(y[0],y[1]),(r,c)
 times=[[],[]]
 for rep in range(8):
    for j in ([0,1] if rep%2==0 else [1,0]):times[j].append(triton.testing.do_bench_cudagraph(calls[j],rep=100))
 rec=dict(rows=r,bytes_per_row=c*4,ms=list(map(statistics.median,times)),regs=[v.n_regs for v in compiled],spills=[v.n_spills for v in compiled])
 print(rec,flush=True);output.append(rec)
(root/"group-cost.json").write_text(json.dumps(output,indent=2))
