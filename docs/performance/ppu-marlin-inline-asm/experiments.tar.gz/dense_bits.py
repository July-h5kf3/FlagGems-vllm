"""Compare normal and overlap bank buffers before GEMMs, for padded scales and byte-offset weights."""
from pathlib import Path
import json,sys,importlib,importlib.util
import torch
root=Path(__file__).parent; name=sys.argv[1]
base=importlib.import_module('flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe')
spec=importlib.util.spec_from_file_location(name,root/(name+'.py'));candidate=importlib.util.module_from_spec(spec);sys.modules[name]=candidate;spec.loader.exec_module(candidate)
torch.manual_seed(342)
shapes=[(65,128),(128,384),(512,256),(256,4096)]
results={}
for pt,q in [('fp8',base.QUANT_TYPE_FP8_E4M3),('int8',base.QUANT_TYPE_UINT8B128),('int4',base.QUANT_TYPE_UINT4B8),('mxfp4',base.QUANT_TYPE_FP4_E2M1)]:
    checks=0; mismatches=0
    for n,k in shapes:
        e=2; w=k//2 if pt in ('int4','mxfp4') else k
        data=torch.randint(0,256,(e*n*w+1,),dtype=torch.uint8,device='cuda')[1:].view(e,n,w)
        g=k//(32 if pt=='mxfp4' else 128)
        if pt=='mxfp4':
            scales=torch.randint(0,256,(e,n+3,g+2),dtype=torch.uint8,device='cuda')[:,:n,:g]
        else:
            scales=torch.randint(-32768,32768,(e,n+3,g+2),dtype=torch.int16,device='cuda').view(torch.bfloat16)[:,:n,:g]
        out0=torch.empty(e*n*k,device='cuda',dtype=torch.bfloat16);out1=torch.empty_like(out0)
        base.decode_dense_bank(data,scales,out0,q)
        for pair_fp8 in ([True,False] if pt=='fp8' else [False]):
            candidate.decode_dense_bank(data,scales,out1,q,pair_fp8=pair_fp8)
            a,b=[x.view(torch.int16).int() & 65535 for x in [out0,out1]]
            nan=((a&32767)>32640)&((b&32767)>32640)
            diff=((a!=b)&~nan).sum().item(); print(pt,n,k,pair_fp8,diff,flush=True)
            assert diff==0,(pt,n,k,pair_fp8,diff)
            checks+=a.numel();mismatches+=diff
    results[pt]=dict(elements=checks,mismatches=mismatches)
(root/('dense-bits-'+name+'.json')).write_text(json.dumps(results,indent=2))
