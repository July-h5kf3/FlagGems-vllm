import importlib,importlib.util,sys,json,statistics
from pathlib import Path
import torch,triton,triton.language as tl,triton.testing
root=Path(__file__).resolve().parent
base=importlib.import_module('flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe')

@triton.jit
def unit(X,Y,Z,O,OP:tl.constexpr,N:tl.constexpr,ITER:tl.constexpr):
    tid=tl.arange(0,256)
    i=tl.program_id(0)*256
    aa=()
    bb=()
    z=()
    for j in tl.static_range(4):aa+=(tl.load(X+(i+tid)*4+j),)
    for j in tl.static_range(N//4):bb+=(tl.load(Y+(i+tid)*(N//4)+j),)
    for j in tl.static_range(N//2):z+=(tl.load(Z+(i+tid)*(N//2)+j),)
    for rep in range(ITER): z=OP(*aa,*bb,*z)
    for j in tl.static_range(N//2):tl.store(O+(i+tid)*(N//2)+j,z[j])

torch.manual_seed(19);rows=256*256
for n,name in [(8,'mma_bf16_m16n8'),(16,'mma_bf16_square')]:
    spec=importlib.util.spec_from_file_location(name,root/(name+'.py')); module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    x=torch.randint(-3,4,(rows,8),device='cuda').bfloat16().view(torch.uint32)
    y=torch.randint(-3,4,(rows,n//2),device='cuda').bfloat16().view(torch.uint32)
    c=torch.randint(-4,5,(rows,n//2),device='cuda').float()
    o=[torch.empty_like(c) for _ in range(2)];res={}
    for repeat in (1,16):
        calls=[lambda m=m,d=d:unit[(rows//256,)](x,y,c,d,getattr(m,name),n,repeat,num_warps=8,num_stages=1) for m,d in zip((base,module),o)]
        compiled=[f() for f in calls];different=(o[0]!=o[1]).sum().item()
        print(n,repeat,'different',different,'ref/cand',o[0][0].tolist(),o[1][0].tolist(),flush=True)
        measures=[[],[]]
        if not different:
            for j in range(6):
                for i in ((0,1) if j%2==0 else (1,0)):measures[i].append(triton.testing.do_bench_cudagraph(calls[i],rep=90))
        res[repeat]=dict(different=different,ms=[statistics.median(a) if a else None for a in measures],regs=[k.n_regs for k in compiled])
    (root/(name+'-micro.json')).write_text(json.dumps(res))
