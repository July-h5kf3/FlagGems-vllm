"""Exhaust byte encodings and BF16 scale bits, checking output per lane including signed zero."""
from pathlib import Path
import importlib.util,sys,json
import torch,triton,triton.language as tl
root=Path(__file__).parent
# Reuse just the unit kernel definitions (no benchmark side effects).
import audit_unit
from audit_unit import unit
base=__import__('importlib').import_module('flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe')
name=sys.argv[1]; spec=importlib.util.spec_from_file_location(name,root/(name+'.py'));new=importlib.util.module_from_spec(spec);sys.modules[name]=new;spec.loader.exec_module(new)
sites=['decode_int8_scaled_bf16','decode_fp8_scaled_bf16_normalized','decode_raw_int4_bf16','decode_raw_mxfp4_bf16','fold_fp8_scale_fragment','decode_int8_fragment_bf16','decode_fp8_pair','decode_i4_register','decode_mx_register']
@triton.jit
def reference_pair(q0,q8,s0,s8):
    a,b=base.decode_int8_fragment_bf16(q0,s0,s0)
    c,d=base.decode_int8_fragment_bf16(q8,s8,s8)
    return a,b,c,d
@triton.jit
def wide_mx(q,s,t):
    return new.decode_mx_register(q,s,t,WIDE=True)
sites.extend(('decode_int8_fragments','decode_mx_register_wide'))
count=1<<18
idx=torch.arange(count,device='cuda',dtype=torch.int32)
out=[torch.empty(count*4,device='cuda',dtype=torch.int32).view(torch.uint32) for _ in range(2)]
res={}
for j in map(int,sys.argv[2].split(',')):
 for fast in ([False,True] if j==6 else [False]):
    key=sites[j]+('-fast' if fast else '');total=0;bad=0
    for chunk in range((1<<24)//count):
        i=idx+chunk*count
        raw=i&255
        # All byte encodings per scale for each of four lanes, with distinct lane values.
        q=(raw | (((raw+17)&255)<<8) | (((raw*3+79)&255)<<16) | ((raw^91)<<24)).view(torch.uint32)
        bits=i>>8
        sf=bits.short().view(torch.bfloat16)
        sw=(bits|(((bits*31+7)&65535)<<16)).view(torch.uint32)
        for mod,d in zip((base,new),out):
            if j==10:op=base.decode_mx_register if mod is base else wide_mx
            else:op=reference_pair if j==9 and mod is base else getattr(mod,sites[j])
            unit[(count//256,)](q,sf,sw,d,op,j,fast,256,num_warps=4)
        length=count*(4 if j in (6,9) else 2 if j>=5 else 1)
        a,b=[t[:length].view(torch.int16).int()&65535 for t in out]
        nan=((a&32767)>32640)&((b&32767)>32640)
        bad+=int(((a!=b)&~nan).sum().item());total+=i.numel()
    res[key]=dict(code_scale_inputs=total,mismatches=bad)
    print(key,res[key],flush=True)
    assert bad==0,(key,bad)
    (root/('exhaust-'+sys.argv[3]+'.json')).write_text(json.dumps(res,indent=2))
