import ast
def node_map(s):
    return {n.name:n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
def extract(s,n):
    return '\n'.join(s.splitlines()[min([n.lineno]+[x.lineno for x in n.decorator_list])-1:n.end_lineno])+'\n'
def inject(base,variant,name):
    before=node_map(base); after=node_map(variant)
    uses=set(); queue=[name]
    while queue:
        n=queue.pop()
        deps=[k.id for k in ast.walk(after[n]) if isinstance(k,ast.Name) and k.id in after and k.id not in before]
        queue.extend(set(deps)-uses);uses.update(deps)
    source='\n\n'.join(extract(variant,n) for n in sorted([after[x] for x in uses]+[after[name]], key=lambda n:n.lineno))
    s=base.replace(extract(base,before[name]),source)
    for key,stmt in [('tl_core','from triton.language import core as tl_core'),('ppu_math','from triton.language.extra.ppu import libdevice as ppu_math')]:
        if key in source and stmt not in s:s=s.replace('import triton.language as tl','import triton.language as tl\n'+stmt,1)
    return s
if __name__=='__main__':
    import sys
    from pathlib import Path
    base=Path(sys.argv[1]).read_text();root=Path(sys.argv[2])
    for key in ['decode_fp8_pair','decode_mx_register','decode_i4_register','decode_int8_fragment_bf16']:
        (root/('prmt_'+key+'.py')).write_text(inject(base,(root/'prmt.py').read_text(),key))
