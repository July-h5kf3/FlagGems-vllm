from pathlib import Path
from gen import replace_body
import sys
base=Path(sys.argv[1]).read_text();out=Path(sys.argv[2])
imp='''from pathlib import Path
from triton.experimental.tle.raw import dialect
from triton.experimental.tle.language import raw as raw_api
'''
for name,sym,body in [('commit','__ppu_async_cp_commit_group','__ppu_async_cp_commit_group();'),
('wait0','__ppu_async_cp_wait_group','__ppu_async_cp_wait_group(0);'),
('wait1','__ppu_async_cp_wait_group','__ppu_async_cp_wait_group(1);')]:
    arg='int' if 'wait' in name else ''
    cu=f'extern "C" __device__ void {sym}({arg});\nextern "C" __device__ void marlin_{name}() {{ {body} }}\n'
    (out/(name+'.cu')).write_text(cu)
    imp+=f'\n@dialect(name="ppu",file=Path(__file__).with_name("{name}.cu"),extern_func_name="marlin_{name}")\ndef raw_{name}(): ...\n'
imp+='\n'
s=base.replace('@triton.jit\ndef commit_w8_tile',imp+'@triton.jit\ndef commit_w8_tile',1)
for name,changes in {
'raw_commit':[('commit_w8_tile','raw_api.call(raw_commit, [], output_indices=[])\nreturn copy_token')],
'raw_wait':[('wait_w8_tile','if KEEP:\n    raw_api.call(raw_wait1, [], output_indices=[])\nelse:\n    raw_api.call(raw_wait0, [], output_indices=[])\ntl.debug_barrier()\nreturn copy_token')],
}.items():
    t=s
    for n,b in changes:t=replace_body(t,n,b)
    (out/(name+'.py')).write_text(t)
