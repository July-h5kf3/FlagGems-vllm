"""Build one-change candidates relative to the pinned PPU operator."""
import ast
from pathlib import Path
import sys

def replace_body(source,name,body):
    node=next(n for n in ast.parse(source).body if getattr(n,'name',None)==name)
    lines=source.splitlines(keepends=True)
    lines[node.body[0].lineno-1:node.end_lineno]=['    '+l+'\n' for l in body.strip().splitlines()]
    return ''.join(lines)

bodies = {
'decode_int8_scaled_bf16':'''return ((q.to(tl.int32) - 128).to(tl.bfloat16) * scale).to(tl.bfloat16)''',
'decode_fp8_scaled_bf16_normalized':'''return (q.to(tl.float8e4nv, bitcast=True).to(tl.bfloat16) * scale).to(tl.bfloat16)''',
'decode_raw_int4_bf16':'''lo = ((b & 15).to(tl.int32) - 8).to(tl.bfloat16)
hi = ((b >> 4).to(tl.int32) - 8).to(tl.bfloat16)
return (lo * scale).to(tl.bfloat16), (hi * scale).to(tl.bfloat16)''',
'decode_raw_mxfp4_bf16':'''return decode_e2m1((b & 15).to(tl.uint32), scale.to(tl.float32), tl.bfloat16), decode_e2m1((b >> 4).to(tl.uint32), scale.to(tl.float32), tl.bfloat16)''',
'fold_fp8_scale_fragment':'''lo = s.to(tl.uint16).to(tl.bfloat16,bitcast=True)
hi = (s >> 16).to(tl.uint16).to(tl.bfloat16,bitcast=True)
return pack_pair(lo.to(tl.float32) * (2.0**120), hi.to(tl.float32) * (2.0**120))''',
'decode_int8_fragment_bf16':'''return decode_byte_pair(q,s0), decode_byte_pair(q >> 16,s1)''',
'decode_fp8_pair':'''r0, r1 = fp8_word(q0, s0, FAST)
r2, r3 = fp8_word(q1, s1, FAST)
return r0, r1, r2, r3''',
'decode_i4_register':'''return decode_nibbles(q,s0,False), decode_nibbles(q >> 8,s1,False)''',
'decode_mx_register':'''return decode_nibbles(q,s0,True), decode_nibbles(q >> 8,s1,True)'''
}
helpers = """
@triton.jit
def pack_pair(lo, hi):
    a = lo.to(tl.bfloat16).to(tl.uint16,bitcast=True).to(tl.uint32)
    b = hi.to(tl.bfloat16).to(tl.uint16,bitcast=True).to(tl.uint32)
    return a | (b << 16)


@triton.jit
def unpack_scales(s):
    return s.to(tl.uint16).to(tl.bfloat16,bitcast=True), (s >> 16).to(tl.uint16).to(tl.bfloat16,bitcast=True)


@triton.jit
def decode_byte_pair(q,s):
    lo,hi=unpack_scales(s)
    a=q.to(tl.uint8).to(tl.int32)-128
    b=(q >> 8).to(tl.uint8).to(tl.int32)-128
    return pack_pair(a.to(tl.float32)*lo.to(tl.float32),b.to(tl.float32)*hi.to(tl.float32))


@triton.jit
def fp8_code(q, FAST:tl.constexpr):
    q=q & 255
    if FAST:
        bits=((q & 128)<<8) | ((q & 127)<<4)
        bits=tl.where((q & 127)==127,bits | 0x7f80,bits)
        return bits.to(tl.uint16).to(tl.bfloat16,bitcast=True)
    else:
        return q.to(tl.uint8).to(tl.float8e4nv,bitcast=True).to(tl.bfloat16)


@triton.jit
def fp8_word(q,s,FAST:tl.constexpr):
    lo,hi=unpack_scales(s)
    a=fp8_code(q,FAST).to(tl.float32)*lo.to(tl.float32)
    b=fp8_code(q>>8,FAST).to(tl.float32)*hi.to(tl.float32)
    c=fp8_code(q>>16,FAST).to(tl.float32)*lo.to(tl.float32)
    d=fp8_code(q>>24,FAST).to(tl.float32)*hi.to(tl.float32)
    return pack_pair(a,b),pack_pair(c,d)


@triton.jit
def decode_nibbles(q,s, MX:tl.constexpr):
    lo,hi=unpack_scales(s)
    if MX:
        a=decode_e2m1(q & 15,lo.to(tl.float32),tl.bfloat16)
        b=decode_e2m1((q>>4) & 15,hi.to(tl.float32),tl.bfloat16)
    else:
        a=((q & 15).to(tl.int32)-8).to(tl.float32)*lo.to(tl.float32)
        b=(((q >> 4) & 15).to(tl.int32)-8).to(tl.float32)*hi.to(tl.float32)
    return pack_pair(a,b)


"""
def build(base, names):
    s=base
    if 'decode_fp8_scaled_bf16_normalized' in names:
        pass
    for name in names:
        s=replace_body(s,name,bodies[name])
    pos=s.index('@triton.jit\ndef decode_int8_fragment_bf16')
    return s[:pos]+helpers+s[pos:]

if __name__=='__main__':
    src=Path(sys.argv[1]).read_text(); out=Path(sys.argv[2])
    (out/'numeric.py').write_text(build(src,list(bodies)))
    for name in bodies:
        (out/(name+'.py')).write_text(build(src,[name]))
