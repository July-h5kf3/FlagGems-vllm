"""Identify BF16 lane/fragment layout with one-hot operands on the target PPU."""
import itertools,json,sys,importlib
import torch,triton,triton.language as tl
from pathlib import Path
op=importlib.import_module('flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe')

@triton.jit
def probe(O,N:tl.constexpr):
    # An independent warp for every one-hot word/half in A and B.
    pid=tl.program_id(0)
    lane=tl.arange(0,32)
    a=pid//(16*N)
    b=pid%(16*N)
    ar=()
    for j in tl.static_range(4):
        q=tl.where(a//8==lane,tl.where(a%8//2==j,0x3f80 << (16*(a%2)),0),0).to(tl.uint32)
        ar+=(q,)
    br=()
    for j in tl.static_range(N//4):
        q=tl.where(b//(N//2)==lane,tl.where(b%(N//2)//2==j,0x3f80 << (16*(b%2)),0),0).to(tl.uint32)
        br+=(q,)
    z=tl.full((32,),0,tl.float32)
    if N==16:
        cs=op.mma_bf16_square(*ar,*br,z,z,z,z,z,z,z,z)
    else:
        cs=op.mma_bf16_m16n8(*ar,*br,z,z,z,z)
    where=z.to(tl.int32)
    for j in tl.static_range(N//2):
        where=tl.where(cs[j]!=0,1+lane*(N//2)+j,where)
    tl.store(O+pid,tl.max(where,0))
for n in (8,16):
    out=torch.empty(256*16*n,device='cuda',dtype=torch.int32)
    probe[(out.numel(),)](out,n,num_warps=1,num_stages=1); t=out.cpu().view(256,16*n).numpy()
    assert ((t>0).sum(0)==16).all() and ((t>0).sum(1)==n).all()
    # Each A element activates the full set of a logical row of Cs; the set
    # of B elements that activate it identifies its K. Label by first appearance.
    rows={};ks={};cols={}; A=[]; B=[]; C=[None]*(16*n)
    for i,r in enumerate(t):
        row=tuple(sorted(int(c-1) for c in r if c)); k=tuple((r>0).nonzero()[0].tolist())
        A.append((rows.setdefault(row,len(rows)),ks.setdefault(k,len(ks))))
    for b,col in enumerate(t.T):
        coords=tuple(sorted(int(c-1) for c in col if c))
        k=next(k for v,k in ks.items() if b in v); B.append((k,cols.setdefault(coords,len(cols))))
    for a,b in zip(*(t>0).nonzero()):
        row,k=A[a];kb,col=B[b];assert k==kb
        coord=(row,col)
        c=t[a,b]-1
        assert C[c] in (None,coord); C[c]=coord
    assert len(rows)==16 and len(ks)==16 and len(cols)==n
    print('N',n,[(s,vals[:18]) for s,vals in [('A',A),('B',B),('C',C)]],flush=True)
    (Path(__file__).parent/f'mma-map-{n}.json').write_text(json.dumps(dict(A=A,B=B,C=C)))
