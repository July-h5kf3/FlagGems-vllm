import triton
import triton.language as tl
@triton.jit
def unit(Q,S,U,OUT, OP:tl.constexpr, SITE:tl.constexpr, FAST:tl.constexpr, BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    q=tl.load(Q+i)
    if SITE < 4:
        scale=tl.load(S+i)
        b=q.to(tl.uint8)
        if SITE==0 or SITE==1:
            value=OP(b,scale)
            word=value.to(tl.uint16,bitcast=True).to(tl.uint32)
        else:
            lo,hi=OP(b,scale)
            word=lo.to(tl.uint16,bitcast=True).to(tl.uint32) | (hi.to(tl.uint16,bitcast=True).to(tl.uint32)<<16)
        tl.store(OUT+i,word)
    else:
        s=tl.load(U+i)
        t=(s<<16)|(s>>16)
        if SITE==4:
            tl.store(OUT+i,OP(s))
        elif SITE==9:
            a,b,c,d=OP(q,~q,s,t)
            tl.store(OUT+4*i,a);tl.store(OUT+4*i+1,b);tl.store(OUT+4*i+2,c);tl.store(OUT+4*i+3,d)
        elif SITE==6:
            a,b,c,d=OP(q,~q,s,t,FAST)
            tl.store(OUT+4*i,a);tl.store(OUT+4*i+1,b);tl.store(OUT+4*i+2,c);tl.store(OUT+4*i+3,d)
        else:
            a,b=OP(q,s,t)
            tl.store(OUT+2*i,a);tl.store(OUT+2*i+1,b)

