import torch

GROUP_SIZE = 128

MXFP4_GROUP_SIZE = 32

_MXFP4_SCALE_DTYPE = torch.float8_e8m0fnu

_E2M1_POS = [0.0,0.5,1.0,1.5,2.0,3.0,4.0,6.0]

_E2M1_MID = [0.25,0.75,1.25,1.75,2.5,3.5,5.0]

_E2M1_MAX = 6.0

def _gptq_quantize_uint4b8(w_2d, group_size):
    """
    Symmetric per-group INT4 quantization with +8 offset (GPTQ uint4b8 convention).

    Self-contained replacement for vllm.quantize_weights(w, scalar_types.uint4b8,
    group_size, False, False). Produces unpacked integer codes (each cell a
    nibble in [0, 15]) plus the exact dequantized FP reference, both compatible
    with the layout fused_moe_kernel_gptq_awq consumes.

    Args:
        w_2d: (out_dim, in_dim), fp16 or bf16.
        group_size: int, must divide in_dim.

    Returns:
        w_ref:  (out_dim, in_dim), same dtype.  Dequantized reference values.
        w_q_unsigned: (out_dim, in_dim), uint8.  Each cell a nibble in [0, 15].
        scales: (out_dim, in_dim // group_size), same dtype as w_2d.
    """
    out_dim, in_dim = w_2d.shape
    assert in_dim % group_size == 0
    ng = in_dim // group_size

    w_grouped = w_2d.reshape(out_dim, ng, group_size).to(torch.float32)
    max_abs = w_grouped.abs().amax(dim=-1, keepdim=True)
    # scale = max_abs / 7  (symmetric INT4 range [-7, 7] after +8 offset -> [1, 15])
    scales_fp = (max_abs / 7.0).clamp(min=1e-8)

    w_q_signed = torch.round(w_grouped / scales_fp).clamp(-7, 7)
    w_ref_grouped = (w_q_signed * scales_fp).to(w_2d.dtype)
    w_q_unsigned = (w_q_signed + 8).clamp(0, 15).to(torch.uint8)

    w_ref = w_ref_grouped.reshape(out_dim, in_dim)
    w_q_unsigned = w_q_unsigned.reshape(out_dim, in_dim)
    scales = scales_fp.squeeze(-1).to(w_2d.dtype)
    return w_ref, w_q_unsigned, scales

def _quantize_moe_weight(w_fp, group_size):
    """
    Apply vLLM's per-expert GPTQ quantization, returning the packed uint8
    weight and bf16/fp16 dequantized reference, in the layout fused MoE
    kernels consume.

    Args:
        w_fp: (E, out_dim, in_dim), fp16 or bf16.
    Returns:
        w_q:    (E, out_dim, in_dim // 2), uint8   (INT4 packed two-per-byte)
        w_ref:  (E, out_dim, in_dim), same dtype as w_fp  (dequantized values)
        scales: (E, out_dim, in_dim // group_size), same dtype as w_fp
    """
    E, out_dim, in_dim = w_fp.shape
    assert (
        in_dim % group_size == 0
    ), f"in_dim={in_dim} not divisible by group_size={group_size}"

    w_q = torch.empty(E, out_dim, in_dim // 2, device=w_fp.device, dtype=torch.uint8)
    w_ref = torch.empty_like(w_fp)
    scales = torch.empty(
        E,
        out_dim,
        in_dim // group_size,
        device=w_fp.device,
        dtype=w_fp.dtype,
    )
    for e in range(E):
        # Self-contained GPTQ uint4b8 quantization (no vllm dependency).
        ref_e, q_e_unpacked, sc_e = _gptq_quantize_uint4b8(w_fp[e], group_size)
        # Pack two nibbles per byte; low nibble = even, high nibble = odd.
        q_e_packed = q_e_unpacked[:, 1::2] * 16 + q_e_unpacked[:, ::2]
        w_q[e] = q_e_packed
        w_ref[e] = ref_e
        scales[e] = sc_e
    return w_q, w_ref, scales

def _make_inputs_w4a16_int4(
    num_tokens, num_experts, hidden_size, intermediate_size, topk, dtype, device
):
    """
    Build all tensors for one test case.

    Returns:
        hidden_states          (M, K)        fp16/bf16
        w1_q, w2_q             packed uint8     -> wrapper input
        w1_ref, w2_ref         fp16/bf16        -> reference GEMM input
        topk_weights, topk_ids
        w1_scale, w2_scale     3D scales matching w1_q/w2_q
    """
    torch.manual_seed(0)
    # Match vLLM's test_fused_marlin_moe magnitude (test_moe.py): A, w1, w2 are
    # all scaled by 1/10 so output magnitudes stay small enough for the fixed
    # atol=4e-2 check (and the INT4 quant grid stays well-conditioned).
    hidden_states = (
        torch.randn(num_tokens, hidden_size, device=device, dtype=dtype) / 10.0
    )

    w1_fp = (
        torch.randn(
            num_experts,
            intermediate_size * 2,
            hidden_size,
            device=device,
            dtype=dtype,
        )
        / 10.0
    )
    w2_fp = (
        torch.randn(
            num_experts,
            hidden_size,
            intermediate_size,
            device=device,
            dtype=dtype,
        )
        / 10.0
    )

    w1_q, w1_ref, w1_scale = _quantize_moe_weight(w1_fp, GROUP_SIZE)
    w2_q, w2_ref, w2_scale = _quantize_moe_weight(w2_fp, GROUP_SIZE)

    gating = torch.randn(num_tokens, num_experts, device=device, dtype=torch.float32)
    topk_weights, topk_ids = torch.topk(torch.softmax(gating, dim=-1), topk, dim=-1)
    topk_weights = topk_weights / topk_weights.sum(dim=-1, keepdim=True)
    topk_weights = topk_weights.to(dtype)

    return (
        hidden_states,
        w1_q,
        w2_q,
        w1_ref,
        w2_ref,
        topk_weights,
        topk_ids,
        w1_scale,
        w2_scale,
    )

def _quantize_mxfp4(w_2d, group_size):
    """Round-to-nearest MXFP4. Returns w_ref (dequant), nibbles (uint8 [0,15]),
    scale_e8m0 (out, in // group_size)."""
    out_dim, in_dim = w_2d.shape
    ng = in_dim // group_size
    device = w_2d.device
    wg = w_2d.reshape(out_dim, ng, group_size).to(torch.float32)
    amax = wg.abs().amax(dim=-1, keepdim=True)
    # E8M0 scale = 2^ceil(log2(amax / 6)) so amax / scale <= 6 (FP4 max).
    exp = torch.ceil(torch.log2((amax / _E2M1_MAX).clamp(min=1e-30))).clamp(-127, 127)
    scale = torch.exp2(exp)
    e8m0_byte = (exp + 127.0).to(torch.uint8)
    wn = wg / scale
    sign = wn < 0
    a = wn.abs().clamp(max=_E2M1_MAX)
    mag = torch.bucketize(a, torch.tensor(_E2M1_MID, device=device))  # 0..7
    q = torch.tensor(_E2M1_POS, device=device)[mag]
    ref = torch.where(sign, -q, q) * scale
    nibbles = (sign.to(torch.uint8) * 8 + mag.to(torch.uint8)).reshape(out_dim, in_dim)
    w_ref = ref.reshape(out_dim, in_dim).to(w_2d.dtype)
    scale_e8m0 = e8m0_byte.squeeze(-1).view(_MXFP4_SCALE_DTYPE)
    return w_ref, nibbles, scale_e8m0

def _quantize_moe_weight_mxfp4(w_fp, group_size):
    """Per-expert MXFP4 in FlagGems layout (packed two nibbles/byte + E8M0 scale)."""
    E, out_dim, in_dim = w_fp.shape
    w_q = torch.empty(E, out_dim, in_dim // 2, device=w_fp.device, dtype=torch.uint8)
    w_ref = torch.empty_like(w_fp)
    scales = torch.empty(
        E,
        out_dim,
        in_dim // group_size,
        device=w_fp.device,
        dtype=_MXFP4_SCALE_DTYPE,
    )
    for e in range(E):
        ref_e, nib_e, sc_e = _quantize_mxfp4(w_fp[e], group_size)
        w_q[e] = nib_e[:, 1::2] * 16 + nib_e[:, ::2]
        w_ref[e] = ref_e
        scales[e] = sc_e
    return w_q, w_ref, scales

def _make_inputs_w4a16_mxfp4(
    num_tokens, num_experts, hidden_size, intermediate_size, topk, dtype, device
):
    torch.manual_seed(0)
    hidden_states = (
        torch.randn(num_tokens, hidden_size, device=device, dtype=dtype) / 10.0
    )
    w1_fp = (
        torch.randn(
            num_experts, intermediate_size * 2, hidden_size, device=device, dtype=dtype
        )
        / 10.0
    )
    w2_fp = (
        torch.randn(
            num_experts, hidden_size, intermediate_size, device=device, dtype=dtype
        )
        / 10.0
    )
    w1_q, w1_ref, w1_scale = _quantize_moe_weight_mxfp4(w1_fp, MXFP4_GROUP_SIZE)
    w2_q, w2_ref, w2_scale = _quantize_moe_weight_mxfp4(w2_fp, MXFP4_GROUP_SIZE)

    gating = torch.randn(num_tokens, num_experts, device=device, dtype=torch.float32)
    topk_weights, topk_ids = torch.topk(torch.softmax(gating, dim=-1), topk, dim=-1)
    topk_weights = (topk_weights / topk_weights.sum(dim=-1, keepdim=True)).to(dtype)
    return (
        hidden_states,
        w1_q,
        w2_q,
        w1_ref,
        w2_ref,
        topk_weights,
        topk_ids,
        w1_scale,
        w2_scale,
    )

def make_weights(fp8):
    """Use the frozen PPU generator; decode identical BF16 baseline weights."""
    torch.manual_seed(7)
    weights, scales, decoded = [], [], []
    for output_size, input_size in ((512, 4096), (4096, 256)):
        raw = torch.randint(
            0, 256, (256, output_size, input_size), device="cuda", dtype=torch.uint8
        )
        if fp8:
            raw = torch.where((raw & 127) == 127, raw - 1, raw)
            weight = raw.view(torch.float8_e4m3fn)
        else:
            weight = raw
        scale = (
            torch.rand((256, output_size, input_size // GROUP_SIZE), device="cuda")
            * 0.001
            + 0.0005
        ).to(torch.bfloat16)
        reference = torch.empty_like(weight, dtype=torch.bfloat16)
        for expert in range(256):
            values = weight[expert].float()
            if not fp8:
                values = values - 128
            reference[expert] = (
                values * scale[expert].float().repeat_interleave(GROUP_SIZE, dim=-1)
            ).to(torch.bfloat16)
        weights.append(weight)
        scales.append(scale)
        decoded.append(reference)
    return weights, scales, decoded

def relative_errors(actual, expected):
    delta = actual.float() - expected.float()
    rms = (
        delta.square().mean().sqrt()
        / expected.float().square().mean().sqrt().clamp_min(1e-12)
    )
    peak = delta.abs().max() / expected.float().abs().max().clamp_min(1e-12)
    return rms.item(), peak.item()

def weights_for(precision):
    if precision in ('int8','fp8'):
        return make_weights(precision == 'fp8')
    gen = _make_inputs_w4a16_int4 if precision == 'int4' else _make_inputs_w4a16_mxfp4
    _,w1,w2,r1,r2,_,_,s1,s2=gen(1,256,4096,256,6,torch.bfloat16,'cuda')
    return [w1,w2],[s1,s2],[r1,r2]

def tokens_for(m):
    torch.manual_seed(7+m)
    x=torch.randn((m,4096),device='cuda',dtype=torch.bfloat16)*.1
    ids=torch.rand((m,256),device='cuda').topk(6,dim=-1).indices
    routing=torch.randn((m,6),device='cuda').softmax(-1)
    return x,ids,routing


def _reference_swiglu_moe(
    hidden_states,
    w1_ref,
    w2_ref,
    topk_weights,
    topk_ids,
    apply_router_weight_on_input=False,
):
    """fp32 dequant-SwiGLU MoE ground truth (weights cast per-expert to avoid a
    full fp32 copy of the (E, *, *) tensors)."""
    M, K = hidden_states.shape
    _, two_N, _ = w1_ref.shape
    N = two_N // 2
    topk = topk_ids.shape[1]
    hs = hidden_states.float()
    tw = topk_weights.float()
    out = torch.zeros(M, K, device=hidden_states.device, dtype=torch.float32)
    for m in range(M):
        x = hs[m]
        for k in range(topk):
            e = topk_ids[m, k].item()
            route_weight = tw[m, k]
            route_input = route_weight * x if apply_router_weight_on_input else x
            gate_up = w1_ref[e].float() @ route_input
            gate, up = gate_up[:N], gate_up[N:]
            act = torch.nn.functional.silu(gate) * up
            y = w2_ref[e].float() @ act
            out[m] += y if apply_router_weight_on_input else route_weight * y
    return out
