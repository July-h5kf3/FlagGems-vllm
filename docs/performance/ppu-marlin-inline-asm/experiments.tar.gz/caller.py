"""Time a single changed site, both in the user-visible call and owning kernel(s)."""
import hashlib,importlib,importlib.util,itertools,json,statistics,sys
from pathlib import Path
import torch,triton,triton.testing
from inputs import weights_for,tokens_for,relative_errors,_reference_swiglu_moe
root=Path(__file__).resolve().parent
precision,variants,shape_csv,tag=sys.argv[1:5]
mods={"base":importlib.import_module("flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe")}
for key in variants.split(','):
    spec=importlib.util.spec_from_file_location("ab_"+key,root/(key+".py"))
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);mods[key]=m
base=mods['base']
q={'fp8':base.QUANT_TYPE_FP8_E4M3,'int8':base.QUANT_TYPE_UINT8B128,'int4':base.QUANT_TYPE_UINT4B8,'mxfp4':base.QUANT_TYPE_FP4_E2M1}[precision]
w,s,decoded=weights_for(precision)
class Watch:
    def __init__(self,entry,name,keep,info): self.entry,self.name,self.keep,self.info=entry,name,keep,info
    def __getitem__(self,grid):
        real=self.entry[grid]
        def run(*a,**kw):
            r=real(*a,**kw); c=r[0] if isinstance(r,tuple) else r
            if self.name=="decode_bank": dims=[a[3],a[4]]
            elif self.name in ('raw_w4_square_kernel','marlin_moe_gemm_grouped_narrow_kernel','marlin_moe_gemm_grouped_square_kernel','quantized_wide_grouped_kernel'): dims=[a[8],a[9]]
            else: dims=[]
            key=self.name+repr(dims)
            if key not in self.keep:
                self.keep[key]=lambda:real(*a,**kw)
                self.info[key]=[c.n_regs,c.n_spills,c.metadata.shared]
            return r
        return run
names=['decode_bank','raw_w4_square_kernel','quantized_wide_grouped_kernel','marlin_moe_gemm_grouped_narrow_kernel','marlin_moe_gemm_grouped_square_kernel','marlin_moe_gemm_direct_kernel','marlin_moe_gemm_reduce_direct_kernel','marlin_moe_gemm_silu_direct_kernel','marlin_moe_gemm_grouped_kernel','marlin_moe_matvec_direct_kernel']
result=[]
for mt in shape_csv.split(','):
    unsafe=mt.endswith('u');m=int(mt.rstrip('u'))
    x,ids,routing=tokens_for(m)
    scales=[t.clone() for t in s] if unsafe else s
    if unsafe: scales[0].mul_(2**20);scales[1].mul_(2**20)
    args=dict(hidden_states=x,w1=w[0],w2=w[1],w1_scale=scales[0],w2_scale=scales[1],bias1=None,bias2=None,topk_ids=ids,topk_weights=routing,quant_type_id=q,group_size=32 if precision=='mxfp4' else 128)
    ops={k:lambda mod=mod:mod.fused_marlin_moe(**args) for k,mod in mods.items()}
    reference=ops['base']();kernels={}; meta={}
    for k,mod in mods.items():
        keep={};meta[k]={}
        prev={name:getattr(mod,name) for name in names}
        for n,obj in prev.items():setattr(mod,n,Watch(obj,n,keep,meta[k]))
        try:actual=ops[k]()
        finally:
            for n,obj in prev.items():setattr(mod,n,obj)
        assert torch.equal(actual.view(torch.int16),reference.view(torch.int16)),(k,mt,relative_errors(actual,reference))
        kernels[k]=keep
    same=set.intersection(*(set(k) for k in kernels.values()))
    stats={}
    for name in ["whole",*sorted(same)]:
        benches=ops if name=="whole" else {k:v[name] for k,v in kernels.items()}
        samples={k:[] for k in benches}
        for i in range(6):
            order=list(benches);offset=(i//2)%len(order);order=order[offset:]+order[:offset]
            for k in (order if i%2==0 else order[::-1]):
                samples[k].append(triton.testing.do_bench_cudagraph(benches[k],rep=70))
        stats[name]=samples
    result.append(dict(shape=mt,resources=meta,ms=stats))
    (root/(tag+'.json')).write_text(json.dumps(result,indent=2))
    print(mt,{n:{k:round(statistics.median(a)*1e3,2) for k,a in v.items()} for n,v in stats.items()},flush=True)
    del kernels, keep, benches, actual,reference
