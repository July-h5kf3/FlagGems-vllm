"""Generate layout conversions to and from actual warp fragment coordinates."""
import sys,json
from pathlib import Path
from gen import replace_body
root=Path(sys.argv[2]); src=Path(sys.argv[1]).read_text()
def addr(perm,v):
    assert sorted(perm)==list(range(len(perm)))
    bits=[]
    for j in range((len(perm)-1).bit_length()):
        b=perm.index(1<<j)
        assert b and not b&(b-1)
        bits.append(b.bit_length()-1)
    assert all(sum(((i>>p)&1)<<j for j,p in enumerate(bits))==a for i,a in enumerate(perm))
    return ' | '.join(f'(({v} & {1<<p}) '+(f'<< {j-p})' if j>=p else f'>> {p-j})') for j,p in enumerate(bits))
for n,fn in [(8,'mma_bf16_m16n8'),(16,'mma_bf16_square')]:
    m=json.loads((root/f'mma-map-{n}.json').read_text())
    masks={}
    for key,width in [('A',16),('B',n),('C',n)]:
        l=[i*width+j for i,j in m[key]]
        masks[key]=addr([l.index(i) for i in range(len(l))],'pos')
        if key=='C':masks['O']=addr(l,'pos')
    # Join registers into a per-thread trailing axis; decode BF16 words.
    lines=[]
    for key,w,qty in [('a',16,4),('b',n,n//4),('c',n,n//2)]:
        def stack(args):
            if len(args)==1:return args[0]
            # join interleaved even/odd halves, so register order is preserved.
            a=stack(args[::2]);b=stack(args[1::2])
            return f'tl.join({a}, {b})'
        top=stack([f'{key}{j}' for j in range(qty)])
        x=key+'vec'
        if key in 'ab':
            lines.append(f'words = {top}')
            lines.append(f'{x}=tl.ravel(tl.join(words.to(tl.uint16).to(tl.bfloat16,bitcast=True),(words>>16).to(tl.uint16).to(tl.bfloat16,bitcast=True)))')
        else:lines.append(f'{x}=tl.ravel({top})')
        lines+=['idx=tl.arange(0,8*256)','warp=idx//256']
        lines+=['pos=idx%256'] if w==16 else ['pos=(idx%256)//16*8+idx%8']
        lines+=[f'{key}=tl.reshape(tl.gather({x}, warp*{16*w}+({masks[key.upper()]}),0),(8,16,16))']
    lines+=['acc=tl.ravel(tl.dot(a,b,acc=c))','tid=tl.arange(0,256)','warp=tid//32']
    outs=[]
    for j in range(n//2):
        lines+=[f'pos=tid%32*{n//2}+{j}',f'idx={masks["O"]}']
        if n==8:lines+=['idx=idx//8*16+idx%8']
        lines+=[f'out{j}=tl.gather(acc,warp*256+idx,0)'];outs.append(f'out{j}')
    lines+=['return '+','.join(outs)]
    (root/(fn+'.py')).write_text(replace_body(src,fn,'\n'.join(lines)))
