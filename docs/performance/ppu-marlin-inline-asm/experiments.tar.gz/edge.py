"""Exercise full and short tiles, odd K-tile counts, and graph-visible scale changes."""
import importlib
import importlib.util
import json
import statistics
import sys
from pathlib import Path
from unittest.mock import patch

import torch
import triton.testing
from tests.test_fused_marlin_moe import _make_inputs_fp8_weight, _make_inputs_w8a16_int8, _reference_w8a16_grouped
from inputs import relative_errors

root=Path(__file__).resolve().parent
base=importlib.import_module("flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe")
spec=importlib.util.spec_from_file_location("edge_candidate", root/(sys.argv[1]+".py"))
candidate=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=candidate
spec.loader.exec_module(candidate)
rows=[]
for precision, make, q in (("int8",_make_inputs_w8a16_int8,base.QUANT_TYPE_UINT8B128),("fp8",_make_inputs_fp8_weight,base.QUANT_TYPE_FP8_E4M3)):
    for k,n in ((1024,384),(7168,1536)):
        torch.manual_seed(19)
        x,a,b,ra,rb,w,ids,s1,s2=make(24,8,k,n,4,torch.bfloat16,"cuda")
        ids[:] = torch.arange(4, device="cuda")
        ids[17:] += 4
        args=(x,a,b,None,None,s1,s2,w,ids,q)
        runs=[lambda m=m:m.fused_marlin_moe(*args) for m in (base,candidate)]
        fn="marlin_moe_gemm_grouped_square_kernel"
        count=[]
        class Wrapper:
            def __getitem__(self,grid):
                count.append(grid)
                return original[grid]
        original=getattr(candidate,fn)
        with patch.object(candidate,fn,Wrapper()):
            assert torch.equal(runs[0](),runs[1]())
        assert len(count)==2,(q,k,n,count)
        with torch.cuda.graph(graph:=torch.cuda.CUDAGraph()): actual = runs[1]()
        trials=[[],[]]
        for i in range(6):
            for j in ((0,1) if i%2==0 else (1,0)):
                trials[j].append(triton.testing.do_bench_cudagraph(runs[j],rep=100))
        for updated in (False,True):
            if updated:
                ids.copy_((ids+1)%8)
                if precision=="fp8":
                    s1.mul_(2**20)
                    ra.mul_(2**20)
            graph.replay()
            expected=runs[0]()
            assert torch.equal(actual,expected)
            oracle=_reference_w8a16_grouped(x,ra,rb,w,ids,False)
            err=relative_errors(actual,oracle)
            assert err[0]<.01 and err[1]<.02, (q,k,n,updated,err)
        row=dict(precision=precision,k=k,n=n,median_ms=list(map(statistics.median,trials)),replay_equal=True,oracle_errors=err)
        print(row,flush=True)
        rows.append(row)
        (root/("edge-"+sys.argv[1]+".json")).write_text(json.dumps(rows,indent=2))
