#!/usr/bin/env bash
set -euo pipefail
# Run inside the existing PPU SDK 2.2.1 environment, with one idle device visible.
checkout=${1:?pass a FlagGems-vllm checkout containing both measured commits}
precision=${2:-fp8}
python_bin=${PYTHON_BIN:-python3}
lab=$(mktemp -d)
here=$(cd "$(dirname "$0")" && pwd)
base_commit=30dc5ae3e1264a617446023c96da6487dc43a78c
code_commit=23d928210d558d6df29147b44d127a5f8e75c8f4
src=src/flaggems_vllm/runtime/backend/_thead/fused
mkdir -p "$lab/repo"
git -C "$checkout" archive "$base_commit" | tar -xf - -C "$lab/repo"
git -C "$checkout" show "$code_commit:$src/marlin_fragments.py" > "$lab/repo/$src/marlin_fragments.py"
git -C "$checkout" show "$code_commit:$src/fused_marlin_moe.py" > "$lab/candidate.py"
cp "$here/"*.py "$here/"*.pygen "$here/shapes.json" "$lab/"
tar -xzf "$here/variants.tar.gz" -C "$lab"
for delta in "$lab/patches/"*.patch; do
    filename=$(basename "$delta" .patch)
    patch -s -o "$lab/$filename.py" "$lab/repo/$src/fused_marlin_moe.py" < "$delta"
done
export PYTHONPATH="$lab/repo/src:$lab/repo${PYTHONPATH:+:$PYTHONPATH}"
export DNN_VENDOR=thead UMD_PLATFORM_TYPE=1 HGGC_DRIVER_CANDIDATE=UMD
printf 'Writing results under %s\n' "$lab"
"$python_bin" "$lab/sweep.py" "$precision" candidate "paired-$precision"
