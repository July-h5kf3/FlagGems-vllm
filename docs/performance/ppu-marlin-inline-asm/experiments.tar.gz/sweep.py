"""Alternate whole operator CUDA Graph measurements; compare full output and FP32 samples."""
import importlib,importlib.util,json,statistics,sys
from pathlib import Path
import torch,triton.testing
from inputs import tokens_for,weights_for,_reference_swiglu_moe,relative_errors
root=Path(__file__).resolve().parent
precision,variant,tag=sys.argv[1:4]
old=importlib.import_module("flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe")
spec=importlib.util.spec_from_file_location(variant,root/(variant+".py"));new=importlib.util.module_from_spec(spec);sys.modules[variant]=new;spec.loader.exec_module(new)
q=dict(fp8=old.QUANT_TYPE_FP8_E4M3,int8=old.QUANT_TYPE_UINT8B128,int4=old.QUANT_TYPE_UINT4B8,mxfp4=old.QUANT_TYPE_FP4_E2M1)[precision]
w,s,decoded=weights_for(precision);res=[]
for shape in json.loads((root/'shapes.json').read_text()):
 m=shape['shape'][0]
 if len(sys.argv)>4 and m not in set(map(int,sys.argv[4].split(','))):continue
 x,ids,r=tokens_for(m)
 def call(mod):return mod.fused_marlin_moe(x,*w,None,None,*s,r,ids,q,group_size=32 if precision=='mxfp4' else 128)
 a=call(old);b=call(new)
 eq=torch.equal(a.view(torch.int16),b.view(torch.int16))
 idx=torch.arange(0,m,max(1,m//16),device=x.device)
 ref=_reference_swiglu_moe(x[idx],*decoded,r[idx],ids[idx])
 err=relative_errors(b[idx],ref);assert eq and err[0]<.01 and err[1]<.02,(precision,m,eq,err)
 calls=[lambda:call(old),lambda:call(new)]
 times=[[],[]]
 for z in range(6):
  for j in ([0,1] if z%2==0 else [1,0]):times[j].append(triton.testing.do_bench_cudagraph(calls[j],rep=75))
 row=dict(m=m,count=shape['count'],bit_equal=eq,oracle=err,trials_ms=times,median_ms=list(map(statistics.median,times)))
 res.append(row);(root/(tag+'.json')).write_text(json.dumps(res,indent=2));print(m,row['median_ms'],flush=True)
