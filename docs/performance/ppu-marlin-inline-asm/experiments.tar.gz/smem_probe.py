import importlib,importlib.util,sys,struct,re,subprocess
from pathlib import Path
import torch,triton,triton.language as tl
from triton.experimental.tle import language as tle
root=Path(__file__).resolve().parent
base=importlib.import_module('flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe')
def load(name):
 spec=importlib.util.spec_from_file_location(name,root/(name+'.py'));mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod

@triton.jit
def probe(X,Y, COPY:tl.constexpr,COMMIT:tl.constexpr,WAIT:tl.constexpr,LD:tl.constexpr,ROWS:tl.constexpr,WIDTH:tl.constexpr,OP:tl.constexpr):
    tid=tl.arange(0,256)
    buf=tle.gpu.alloc([ROWS*WIDTH],tl.uint8,layout=None,scope=tle.gpu.smem,nv_mma_shared_layout=False)
    shared=tle.gpu.local_ptr(buf,(0,)).to(tl.int64).to(tl.int32)
    token=tl.full((256,),0,tl.int32)
    token=COPY(shared,X.to(tl.pointer_type(tl.uint8)),ROWS,WIDTH,WIDTH,0,token)
    token=COMMIT(token)
    token=WAIT(token,False)
    if OP==0:
        # Read through the same swizzled matrix load as the production consumer.
        a,b,c,d=base.load_matrix_x4(shared,0,ROWS,0,token)
        tl.store(Y+tid*4,a);tl.store(Y+tid*4+1,b);tl.store(Y+tid*4+2,c);tl.store(Y+tid*4+3,d)
    elif OP==1:
        a,b,c,d=LD(shared,0,ROWS,0,token)
        tl.store(Y+tid*4,a);tl.store(Y+tid*4+1,b);tl.store(Y+tid*4+2,c);tl.store(Y+tid*4+3,d)
    elif OP==2:
        a,b=LD(shared,0,token)
        tl.store(Y+tid*2,a);tl.store(Y+tid*2+1,b)

variant=sys.argv[1];mod=load(variant)
typ={'load_matrix_x4':1,'load_activation_fragment_x2':2}.get(variant,0)
rows=8 if typ==2 else 64
torch.manual_seed(91)
x=torch.randint(-(2**31),2**31-1,(rows,32),dtype=torch.int32,device='cuda')
out=torch.empty(1024,dtype=torch.int32,device='cuda'); other=torch.empty_like(out);out.zero_();other.zero_()
def args(m,o):
 return (x,o,m.copy_w8_tile_async,m.commit_w8_tile,m.wait_w8_tile,m.load_activation_fragment_x2 if typ==2 else m.load_matrix_x4,rows,128,typ)
for m,o in [(base,out),(mod,other)]:
 c=probe.warmup(*args(m,o),grid=(1,),num_warps=8,num_stages=1)
 binary=root/(variant+'-'+('base' if m is base else 'alt')+'.hgbin')
 binary.write_bytes(c.asm['hgbin'])
 isa=subprocess.check_output(['hgobjdump','--arch=ppu1.0','--dump-isa',str(binary)],text=True)
 (binary.with_suffix('.isa')).write_text(isa)
 if variant.startswith(('ttg_', 'raw_', 'sdk_')) and m is mod:
    print('CHECK COMPILED ORDER BEFORE LAUNCH',flush=True)
    break
 probe[(1,)](*args(m,o),num_warps=8,num_stages=1)
 torch.cuda.synchronize()
else:
 print('mismatched words:',(out!=other).sum().item(),'baseline/candidate first:',out[:20].tolist(),other[:20].tolist(),flush=True)
 assert torch.equal(out,other)
