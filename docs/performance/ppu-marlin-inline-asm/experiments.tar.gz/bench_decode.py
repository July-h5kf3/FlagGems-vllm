"""Bit-level differential and paired timing of each packed conversion primitive."""
import importlib, importlib.util, sys,json,statistics,time
from pathlib import Path
import torch, triton, triton.language as tl
import triton.testing
root=Path(__file__).resolve().parent
old=importlib.import_module("flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe")
def load(name):
    spec=importlib.util.spec_from_file_location(name,root/(name+'.py')); m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
new=load(sys.argv[1])

@triton.jit
def unit(Q,S,U,OUT, OP:tl.constexpr, SITE:tl.constexpr, FAST:tl.constexpr, BLOCK:tl.constexpr):
    i=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    q=tl.load(Q+i)
    if SITE < 4:
        scale=tl.load(S+i)
        b=q.to(tl.uint8)
        if SITE==0 or SITE==1:
            value=OP(b,scale)
            word=value.to(tl.uint16,bitcast=True).to(tl.uint32)
        else:
            lo,hi=OP(b,scale)
            word=lo.to(tl.uint16,bitcast=True).to(tl.uint32) | (hi.to(tl.uint16,bitcast=True).to(tl.uint32)<<16)
        tl.store(OUT+i,word)
    else:
        s=tl.load(U+i)
        t=(s<<16)|(s>>16)
        if SITE==4:
            tl.store(OUT+i,OP(s))
        elif SITE==6:
            a,b,c,d=OP(q,~q,s,t,FAST)
            tl.store(OUT+4*i,a);tl.store(OUT+4*i+1,b);tl.store(OUT+4*i+2,c);tl.store(OUT+4*i+3,d)
        else:
            a,b=OP(q,s,t)
            tl.store(OUT+2*i,a);tl.store(OUT+2*i+1,b)

def same(a,b):
    a=a.view(torch.int16).int()&65535;b=b.view(torch.int16).int()&65535
    nan=((a&0x7fff)>0x7f80)&((b&0x7fff)>0x7f80)
    return (a!=b)&~nan

sites=['decode_int8_scaled_bf16','decode_fp8_scaled_bf16_normalized','decode_raw_int4_bf16','decode_raw_mxfp4_bf16','fold_fp8_scale_fragment','decode_int8_fragment_bf16','decode_fp8_pair','decode_i4_register','decode_mx_register']
torch.manual_seed(314)
N=1<<19
i=torch.arange(N,device='cuda',dtype=torch.int32)
q=(i*0x0103070b).view(torch.uint32)
s16=((i>>8)*193 + (i&255)*73).short()
sf=s16.view(torch.bfloat16)
s=((s16.int()&65535)|((s16.int()*313+71)<<16)).view(torch.uint32)
# Explicitly cover endpoints, nonfinites, subnormal and signed scale lanes.
edge=torch.tensor([0,128,1,127,129,255,7,8,15,16,112,240,126,254],device='cuda',dtype=torch.int32)
v=torch.tensor([0,32768,1,128,32639,32640,32641,65408,65535,0x3f80,0xbf80,0x4300,0x4380],device='cuda',dtype=torch.int32)
qe=edge.repeat(v.numel()); se=v.repeat_interleave(edge.numel()); nn=qe.numel()
q[:nn].copy_((qe*0x01010101).view(torch.uint32)); sf[:nn].copy_(se.short().view(torch.bfloat16)); s[:nn].copy_(((se<<16)|se).view(torch.uint32))
results={}
for j in map(int,sys.argv[2].split(',')):
  for fast in ([False,True] if j==6 else [False]):
    name=sites[j]; tag=name+('-fast' if fast else '')
    out=[torch.empty(N*(4 if j==6 else 2 if j>=5 else 1),device='cuda',dtype=torch.uint32) for _ in range(2)]
    try:
        ops=[getattr(m,name) for m in (old,new)]; calls=[lambda a=a,b=b: unit[(N//256,)](q,sf,s,b,a,j,fast,256,num_warps=4) for a,b in zip(ops,out)]
        compiled=[c() for c in calls]; mask=same(*out); bad=mask.sum().item()
        if bad:
            index=mask.nonzero()[0].item()
            print(tag,'mismatch',bad,'i16',index,[hex(x.view(torch.int16)[index].item()&65535) for x in out])
        times=[[],[]]
        for r in range(6):
            for n in ([0,1] if r%2==0 else [1,0]): times[n].append(triton.testing.do_bench_cudagraph(calls[n],rep=100))
        results[tag]=dict(mismatch=bad,ms=list(map(statistics.median,times)),regs=[c.n_regs for c in compiled],spills=[c.n_spills for c in compiled])
    except Exception as ex: results[tag]=dict(error=str(ex))
    print(tag,results[tag],flush=True)
    (root/(sys.argv[3]+'.json')).write_text(json.dumps(results,indent=2))
