from gen import replace_body
import sys
from pathlib import Path
base=Path(sys.argv[1]).read_text();root=Path(sys.argv[2])
# Direct packed E4M3FN conversion uses exponent alignment and the original two multiplications.
fp8='''payload=q.to(tl.uint16)
m=payload & 127
bits=((payload & 128)<<8) | (m<<4) | (-((m+1)>>7) & 0x7f80)
tiny=bits.to(tl.bfloat16,bitcast=True)
value=(tiny.to(tl.float32)*(2.0**120)).to(tl.bfloat16)
return (value*scale).to(tl.bfloat16)'''
mx='''low=((b&15).to(tl.uint16)*0x1040)&0x81c0
high=((b>>4).to(tl.uint16)*0x1040)&0x81c0
lo=(low.to(tl.bfloat16,bitcast=True).to(tl.float32)*(2.0**126)).to(tl.bfloat16)
hi=(high.to(tl.bfloat16,bitcast=True).to(tl.float32)*(2.0**126)).to(tl.bfloat16)
return (lo*scale).to(tl.bfloat16),(hi*scale).to(tl.bfloat16)'''
i4='''lo=((b&15).to(tl.uint16)|0x4300).to(tl.bfloat16,bitcast=True)-136.
hi=((b>>4).to(tl.uint16)|0x4300).to(tl.bfloat16,bitcast=True)-136.
return (lo*scale).to(tl.bfloat16),(hi*scale).to(tl.bfloat16)'''
for name,body in [('decode_fp8_scaled_bf16_normalized',fp8),('decode_raw_int4_bf16',i4),('decode_raw_mxfp4_bf16',mx)]:
 (root/('bits_'+name+'.py')).write_text(replace_body(base,name,body))
# SDK exposes an unmasked shuffle intrinsic, unlike the C byte_perm interface
# which forces the high bit of each selector to zero. Try native sign expansion.
s=(root/'libmath.py').read_text().replace('from triton.language.extra.ppu import libdevice as ppu_math','')
a=s.index('@triton.jit\ndef perm32');b=s.index('@triton.jit\ndef fp8_word_packed',a)
s=s[:a]+'''@tl_core.extern
def native_prmt(a,b,c,_semantic=None):
    return tl_core.extern_elementwise("", "", [a,b,c], {(tl_core.uint32,tl_core.uint32,tl_core.uint32):("llvm.nvvm.prmt",tl_core.uint32)},is_pure=True,_semantic=_semantic)

@triton.jit
def perm32(a,b,c):
    return native_prmt((a+tl.full((),0,tl.uint32)).to(tl.uint32),(b+tl.full((),0,tl.uint32)).to(tl.uint32),(c+tl.full((),0,tl.uint32)).to(tl.uint32))


'''+s[b:]
s=s.replace('nan=((mag+0x01010101)&0x80808080)>>7','nan=perm32(mag+0x01010101,0,0xba98)').replace('(nan*0x7f)','(nan&0x7f7f7f7f)').replace(' | (nan<<7)','')
s=s.replace('sign=perm32(q,q>>4,0x5140)\n    high=high|((sign<<4)&0x80808080)','sign=perm32(0x80808080,0x80808080,q)\n    high=high|((sign<<1)&0x80808080)')
(root/'prmt.py').write_text(s)
# Fold before broadcast when the incoming scale already lives in a BF16 scalar.
s=replace_body(base,'fold_fp8_scale_fragment', '''lo=s.to(tl.uint16).to(tl.bfloat16,bitcast=True)
hi=(s>>16).to(tl.uint16).to(tl.bfloat16,bitcast=True)
lo=(lo.to(tl.float32)*(2.0**120)).to(tl.bfloat16).to(tl.uint16,bitcast=True).to(tl.uint32)
hi=(hi.to(tl.float32)*(2.0**120)).to(tl.bfloat16).to(tl.uint16,bitcast=True).to(tl.uint32)
return lo | (hi << 16)''')
s=s.replace('        bits = scale.to(tl.uint16, bitcast=True).to(tl.uint32)','        if FOLD:\n            scale=(scale.to(tl.float32)*(2.0**120)).to(tl.bfloat16)\n        bits = scale.to(tl.uint16, bitcast=True).to(tl.uint32)').replace('    if FOLD and not PACKED:\n        fragment = fold_fp8_scale_fragment(fragment)\n','')
(root/'scalar_fold.py').write_text(s)
