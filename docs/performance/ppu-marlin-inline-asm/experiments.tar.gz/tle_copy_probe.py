"""Test both public gpu.copy forms with the same tile and logical swizzle."""
import sys,json,subprocess
import torch,triton,triton.language as tl
from triton.experimental.tle import language as tle
from pathlib import Path
root=Path(__file__).resolve().parent
@triton.jit
def copy_probe(X,Y, DESC:tl.constexpr):
    R:tl.constexpr=64
    C:tl.constexpr=32
    buf=tle.gpu.alloc([R,C],tl.uint32,scope=tle.gpu.smem,layout=None,nv_mma_shared_layout=False)
    row=tl.arange(0,R)[:,None]
    col=tl.arange(0,C)[None,:]
    if DESC:
        desc=tl.make_tensor_descriptor(X,[R,C],[C,1],[R,C])
        tle.gpu.copy(desc,buf,(R,C),offsets=[0,0])
    else:
        # Source indices in the physical order of the scratch tile (dword units).
        pos=row*C+col
        sector=pos//(R*8)
        rotated=pos//8%R
        skew=((sector&1)<<1)|((sector>>1)&1)
        logical_row=(rotated & ~3) | ((rotated-skew)&3)
        logical_col=sector*8+((pos%8)^(((logical_row//4)&1)*4))
        tle.gpu.copy(X+logical_row*C+logical_col,buf,(R,C))
    tl.debug_barrier()
    ptr=tle.gpu.local_ptr(buf,(row+col*0,col+row*0))
    tl.store(Y+row*C+col,tl.load(ptr))

for desc in [False,True]:
    x=torch.arange(2048,device='cuda',dtype=torch.int32).view(torch.uint32)
    y=torch.empty_like(x)
    try:
        args=x,y,desc
        c=copy_probe.warmup(*args,grid=(1,),num_warps=8,num_stages=1)
        binary=root/('desc'+str(desc)+'.hgbin');binary.write_bytes(c.asm['hgbin'])
        isa=subprocess.check_output(['hgobjdump','--arch=ppu1.0','--dump-isa',str(binary)],text=True)
        binary.with_suffix('.isa').write_text(isa)
        copy_probe[(1,)](*args,num_warps=8,num_stages=1)
        pos=torch.arange(2048,dtype=torch.int32);sector=pos//512;rot=pos//8%64;row=(rot&~3)|((rot-(((sector&1)<<1)|((sector>>1)&1)))&3)
        want=pos if desc else row*32+sector*8+((pos%8)^(((row//4)&1)*4))
        assert torch.equal(y.cpu().view(torch.int32),want)
        print('verified',desc,'aiu',sum('aiu' in x.lower() for x in isa.splitlines()),flush=True)
    except Exception as ex:
        import traceback
        traceback.print_exc()
