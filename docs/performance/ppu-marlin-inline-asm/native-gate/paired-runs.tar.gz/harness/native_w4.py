"""Prepare exact W4 inputs for the released SAIL W4A16 DeepGEMM experts."""
from types import SimpleNamespace
import torch


def make_kernel(config, precision, weights, scales):
    from vllm.model_executor.layers.fused_moe.config import (
        int4_w4a16_moe_quant_config, mxfp4_w4a16_moe_quant_config,
    )
    from vllm.model_executor.layers.fused_moe.modular_kernel import FusedMoEKernel
    from vllm.model_executor.layers.fused_moe.prepare_finalize.no_dp_ep import (
        make_moe_prepare_and_finalize_no_dp_ep,
    )
    from vllm.model_executor.layers.quantization.utils.marlin_utils import marlin_moe_permute_scales
    from vllm.model_executor.layers.quantization.utils.marlin_utils_fp4 import (
        _repack_marlin_experts, prepare_moe_mxfp4_layer_for_marlin,
    )
    from vllm_sail.model_executor.layers.fused_moe.experts.deep_gemm_moe import PPUDeepGemmExperts

    assert PPUDeepGemmExperts._supports_current_device()
    if precision == 'mxfp4':
        layer = SimpleNamespace(params_dtype=torch.bfloat16)
        w1, w2, s1, s2, _, _ = prepare_moe_mxfp4_layer_for_marlin(
            layer, *weights, *scales, None, None,
        )
        quant = mxfp4_w4a16_moe_quant_config(s1, s2)
    else:
        packed, permuted = [], []
        for weight, scale in zip(weights, scales):
            output_size, input_size = weight.shape[1], weight.shape[2] * 2
            packed.append(_repack_marlin_experts(weight, output_size, input_size, False))
            # Repeating each group-128 scale four times represents identical
            # INT4 values with the native backend's group-32 metadata.
            expanded = scale.repeat_interleave(4, dim=-1)
            permuted.append(marlin_moe_permute_scales(
                expanded.transpose(1, 2).contiguous(), input_size, output_size, 32,
            ))
        w1, w2 = packed
        quant = int4_w4a16_moe_quant_config(*permuted, block_shape=[0, 32])
    experts = PPUDeepGemmExperts(config, quant)
    prepare_finalize = make_moe_prepare_and_finalize_no_dp_ep(use_monolithic=False)
    return FusedMoEKernel(prepare_finalize, experts), [w1, w2]
