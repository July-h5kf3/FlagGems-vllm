"""Persistent worker; keeps the vendor and FlagTree Triton imports separate."""
import argparse
import hashlib
import importlib.metadata
import json
import os
import sys
from pathlib import Path

import torch

# Establish the selected-device context before heavyweight vLLM imports.
_context_reservation = torch.empty(1, device="cuda")
torch.cuda.synchronize()
import triton
import triton.testing

from inputs import relative_errors, tokens_for, weights_for, _reference_swiglu_moe

parser = argparse.ArgumentParser()
parser.add_argument('--engine', choices=['vendor', 'candidate'], required=True)
parser.add_argument('--precision', required=True)
parser.add_argument('--job', required=True)
parser.add_argument('--native-w4', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent
source_sha256 = None
source_file = None


def digest(tensors):
    h = hashlib.sha256()
    for tensor in tensors:
        h.update(str((tuple(tensor.shape), str(tensor.dtype))).encode())
        h.update(tensor.contiguous().view(torch.uint8).cpu().numpy().tobytes())
    return h.hexdigest()


def respond(value):
    print('@@PR752@@' + json.dumps(value), flush=True)


if args.engine == 'vendor':
    from vllm.platforms import current_platform
    from vllm_sail.compat import check_vllm_compatibility
    from vllm_sail.registry import moe_backends, tuned_configs

    assert current_platform.is_ppu()
    check_vllm_compatibility()
    current_platform.import_kernels()
    tuned_configs.register()
    moe_backends.register()
    from vllm.v1.worker.workspace import init_workspace_manager
    init_workspace_manager(torch.device("cuda",0))
    from vllm.model_executor.layers.fused_moe.activation import MoEActivation
    from vllm.model_executor.layers.fused_moe.config import (
        FusedMoEConfig, FusedMoEParallelConfig, FusedMoEQuantConfig, RoutingMethodType,
    )
    from vllm.model_executor.layers.fused_moe.oracle.unquantized import (
        make_unquantized_moe_kernel, select_unquantized_moe_backend,
    )

    parallel = FusedMoEParallelConfig(
        tp_size=1, pcp_size=1, dp_size=1, ep_size=1, tp_rank=0, pcp_rank=0,
        dp_rank=0, ep_rank=0, sp_size=1, use_ep=False,
        all2all_backend='naive', enable_eplb=False,
    )
    config = FusedMoEConfig(
        num_experts=256, experts_per_token=6, hidden_dim=4096,
        intermediate_size=256, num_local_experts=256, num_logical_experts=256,
        activation=MoEActivation.SILU, device='cuda',
        routing_method=RoutingMethodType.Unspecified,
        moe_parallel_config=parallel, in_dtype=torch.bfloat16, max_num_tokens=16384,
    )
    backend, experts = select_unquantized_moe_backend(config)
    assert experts.__name__ == 'PPUDeepGemmExperts', (backend, experts)
    kernel = make_unquantized_moe_kernel(FusedMoEQuantConfig.make(), config, backend, experts)
    backend_name = f'{backend.value}/{experts.__module__}.{experts.__name__}'
else:
    import flaggems_vllm
    from flaggems_vllm.ops.fused_marlin_moe import (
        QUANT_TYPE_FP4_E2M1, QUANT_TYPE_FP8_E4M3,
        QUANT_TYPE_UINT4B8, QUANT_TYPE_UINT8B128,
    )
    assert flaggems_vllm.fused_marlin_moe.__module__ == 'flaggems_vllm.runtime.backend._thead.fused.fused_marlin_moe'
    source_file = importlib.import_module(flaggems_vllm.fused_marlin_moe.__module__).__file__
    source_sha256 = hashlib.sha256(Path(source_file).read_bytes()).hexdigest()
    assert source_sha256 == os.environ.get(
        'PR23_CANDIDATE_SHA256',
        'f5b2d7e7c46066701b9cc69de541d5a0967681dc92bba7cc851f73d9d5d8dc0c',
    ), (source_file, source_sha256)
    quant = {'int8': QUANT_TYPE_UINT8B128, 'fp8': QUANT_TYPE_FP8_E4M3,
             'int4': QUANT_TYPE_UINT4B8, 'mxfp4': QUANT_TYPE_FP4_E2M1}[args.precision]
    backend_name = flaggems_vllm.fused_marlin_moe.__module__

weights, scales, decoded = weights_for(args.precision)
if args.engine == 'vendor' and args.native_w4:
    from native_w4 import make_kernel
    kernel, native_weights = make_kernel(config, args.precision, weights, scales)
    backend_name = 'PPUDeepGemmExperts/' + args.precision + '-W4A16'
else:
    native_weights = decoded
weight_hash = digest(weights + scales)
respond(dict(event='ready', pid=os.getpid(), weights_sha256=weight_hash,
             uuid=str(torch.cuda.get_device_properties(0).uuid),
             backend=backend_name, source_sha256=source_sha256, source_file=source_file, torch=torch.__version__, triton=triton.__version__,
             vllm=importlib.metadata.version('vllm'),
             sail=importlib.metadata.version('vllm-sail'), deep_gemm=importlib.metadata.version('deep-gemm'), diagnostic_continue=True))
current_m = None
for line in sys.stdin:
    command = json.loads(line)
    if command['action'] == 'quit':
        break
    if command['action'] == 'prepare':
        current_m = command['m']
        x, ids, routing = tokens_for(current_m)
        if args.engine == 'vendor':
            def call():
                return kernel.apply(x, *native_weights, routing, ids, MoEActivation.SILU, 256, None, False)
        else:
            def call():
                return flaggems_vllm.fused_marlin_moe(
                    hidden_states=x, w1=weights[0], w2=weights[1],
                    w1_scale=scales[0], w2_scale=scales[1],
                    topk_weights=routing, topk_ids=ids, bias1=None, bias2=None,
                    quant_type_id=quant, group_size=32 if args.precision == 'mxfp4' else 128,
                )
        actual = call()
        assert actual.shape == x.shape and torch.isfinite(actual).all().item()
        reference_file = root / 'references' / args.job / f'{args.precision}-{current_m}.pt'
        reference_file.parent.mkdir(parents=True, exist_ok=True)
        errors = None
        oracle_errors = None
        diagnostic = None
        if args.engine == 'vendor':
            oracle = _reference_swiglu_moe(x, *decoded, routing, ids)
            oracle_errors = relative_errors(actual, oracle)
            if not (oracle_errors[0] < .01 and oracle_errors[1] < .02):
                torch.save(dict(native=actual.cpu(),fp32=oracle.cpu(),errors=oracle_errors),reference_file.with_name(reference_file.stem+'-native-f32-failed.pt'))
            del oracle
        if args.engine == 'vendor':
            torch.save(actual.cpu(), reference_file)
        else:
            reference = torch.load(reference_file, weights_only=True).to('cuda')
            errors = relative_errors(actual, reference)
            if not (errors[0] < .01 and errors[1] < .02):
                oracle = _reference_swiglu_moe(x, *decoded, routing, ids)
                candidate_oracle = relative_errors(actual, oracle)
                native_oracle = relative_errors(reference, oracle)
                diagnostic = dict(candidate_oracle_errors=candidate_oracle, native_oracle_errors=native_oracle)
                torch.save(dict(candidate=actual.cpu(), native=reference.cpu(), fp32=oracle.cpu()), reference_file.with_name(reference_file.stem+'-diagnostic.pt'))
                assert candidate_oracle[0] < .01 and candidate_oracle[1] < .02, diagnostic
                del oracle
            del reference
        del actual
        respond(dict(event='prepared', m=current_m, input_sha256=digest([x, ids, routing]), errors=errors, oracle_errors=oracle_errors, diagnostic=diagnostic))
    elif command['action'] == 'bench':
        assert current_m == command['m']
        latency = triton.testing.do_bench_cudagraph(call, rep=command['rep'])
        respond(dict(event='timed', m=current_m, latency_ms=latency))
    else:
        raise ValueError(command)
