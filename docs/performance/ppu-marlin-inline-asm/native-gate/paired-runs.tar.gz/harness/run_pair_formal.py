"""Run two isolated Python environments, alternating measurements on one PPU."""
import argparse
import csv
import json
import os
import signal
import statistics
import subprocess
import threading
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--gpu', type=int, required=True, help='Host physical index')
parser.add_argument('--device', type=int, required=True, help='Runtime ordinal in this container')
parser.add_argument('--job', required=True)
parser.add_argument('--precision', default='int8,fp8,int4,mxfp4')
parser.add_argument('--tokens')
parser.add_argument('--shard-i', type=int, default=0)
parser.add_argument('--shard-n', type=int, default=1)
parser.add_argument('--rep', type=int, default=100)
parser.add_argument('--native-w4', action='store_true')
parser.add_argument('--deepgemm-release', action='store_true')
parser.add_argument('--candidate-repo', default='repo')
parser.add_argument('--candidate-sha256', default='f5b2d7e7c46066701b9cc69de541d5a0967681dc92bba7cc851f73d9d5d8dc0c')
args = parser.parse_args()
root = Path(__file__).resolve().parent
container = 'ldc-pr23-upstream-sdk221-20261120'
sdk_ld = subprocess.check_output(['docker', 'exec', container, 'sh', '-c',
                                  'printf "%s" "$LD_LIBRARY_PATH"'], text=True)


def query(kind, fields):
    value = subprocess.check_output(['nvidia-smi', '--query-' + kind + '=' + fields,
                                     '--format=csv,noheader'], text=True, timeout=10)
    return list(csv.reader(value.splitlines(), skipinitialspace=True))


device = next(r for r in query('gpu', 'index,uuid,utilization.gpu,memory.used') if int(r[0]) == args.gpu)
uuid = device[1]


def pids():
    return {r[1] for r in query('compute-apps', 'gpu_uuid,pid') if r[0] == uuid}


def check_idle():
    current = next(r for r in query('gpu', 'index,utilization.gpu,memory.used') if int(r[0]) == args.gpu)
    assert not pids() and int(current[1].split()[0]) == 0 and int(current[2].split()[0]) <= 16, current


def job_pids():
    value = subprocess.check_output(['docker', 'top', container, '-eo', 'pid,args'], text=True)
    return {r.split(None, 1)[0] for r in value.splitlines()[1:]
            if 'worker_diagnostic.py' in r and '--job ' + args.job + ' ' in r + ' '}


class Worker:
    def __init__(self, engine, precision):
        python = '/opt/vendor031/bin/python' if engine == 'vendor' else '/opt/candidate031/bin/python'
        env = dict(UMD_PLATFORM_TYPE='1', HGGC_DRIVER_CANDIDATE='UMD',
                   CUDA_VISIBLE_DEVICES=str(args.device), HGGC_VISIBLE_DEVICES=str(args.device),
                   VLLM_PLUGINS='ppu', DNN_VENDOR='thead', PR23_CANDIDATE_SHA256=args.candidate_sha256,
                   DG_JIT_CACHE_DIR='/work/pr23-vllm033-20261119/deep-gemm-cache-sdk221',
                   LD_LIBRARY_PATH='/opt/host-driver:' + sdk_ld,
                   PYTHONPATH=('/work/pr23-vllm033-20261119/vendor:/work'
                               if engine == 'vendor'
                               else f'/work/pr23-vllm033-20261119/vendor:/work/deps:/work/pr23-vllm033-20261119/{args.candidate_repo}/src:/work'))
        if args.deepgemm_release:
            env['PYTHONPATH'] = '/work/pr23-vllm033-20261119/deepgemm-new:' + env['PYTHONPATH']
            env['DG_JIT_CACHE_DIR'] += '-v110'
        command = ['docker', 'exec', '-i']
        for key, value in env.items():
            command += ['-e', key + '=' + value]
        command += [container, python, '-u', '/work/pr23-vllm033-20261119/worker_diagnostic.py', '--engine', engine,
                    '--precision', precision, '--job', args.job]
        if args.native_w4 and precision in ('int4', 'mxfp4'):
            command += ['--native-w4']
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=subprocess.STDOUT, text=True, bufsize=1)
        self.log = (root / f'{args.job}-{precision}-{engine}.log').open('w', buffering=1)

    def receive(self):
        for line in self.process.stdout:
            self.log.write(line)
            if line.startswith('@@PR752@@'):
                return json.loads(line[len('@@PR752@@'):])
        raise RuntimeError('Worker exited; see ' + self.log.name)

    def request(self, command):
        self.process.stdin.write(json.dumps(command) + '\n')
        self.process.stdin.flush()
        return self.receive()


shapes = json.loads((root / 'shapes53.json').read_text())[args.shard_i::args.shard_n]
if args.tokens:
    chosen = set(map(int, args.tokens.split(',')))
    shapes = [r for r in shapes if r['shape'][0] in chosen]
assert shapes
result = dict(gpu=args.gpu, runtime_device=args.device, uuid=uuid, rep_ms=args.rep,
              rounds=3, native_w4=args.native_w4, results={}, completed=False, diagnostic_continue=True)
output = root / (args.job + '.json')
for precision in args.precision.split(','):
    check_idle()
    workers = {}
    finished = threading.Event()
    monitor = None
    monitor_log = (root / f'{args.job}-{precision}-device.jsonl').open('w', buffering=1)
    try:
        workers['vendor'] = Worker('vendor', precision)
        vendor_ready = workers['vendor'].receive()
        workers['candidate'] = Worker('candidate', precision)
        candidate_ready = workers['candidate'].receive()
        assert vendor_ready['weights_sha256'] == candidate_ready['weights_sha256']
        assert all(r['uuid'].removeprefix('GPU-') == uuid.removeprefix('GPU-') for r in (vendor_ready, candidate_ready))
        host_owned = job_pids()
        owned = pids()
        # DSW Docker PIDs and the SDK-3 NVML PIDs use different namespaces.
        # Both workers own live CUDA tensors, the UUIDs match, and the card was idle.
        assert len(host_owned) == len(owned) == 2, (host_owned, owned)
        monitor_log.write(json.dumps(dict(initial=device, owned=sorted(owned),
                                         docker_pids=sorted(host_owned), time=time.time())) + '\n')

        def watch():
            while not finished.wait(1):
                try:
                    current = pids()
                    monitor_log.write(json.dumps(dict(time=time.time(), pids=sorted(current))) + '\n')
                    if current != owned:
                        raise RuntimeError('GPU contexts changed')
                except Exception as error:
                    monitor_log.write(json.dumps(dict(aborted=str(error))) + '\n')
                    for pid in job_pids():
                        os.kill(int(pid), signal.SIGTERM)
                    return

        monitor = threading.Thread(target=watch, daemon=True)
        monitor.start()
        rows = []
        result['results'][precision] = dict(ready={'vendor': vendor_ready, 'candidate': candidate_ready}, rows=rows)
        for shape in shapes:
            m = shape['shape'][0]
            vendor = workers['vendor'].request(dict(action='prepare', m=m))
            candidate = workers['candidate'].request(dict(action='prepare', m=m))
            assert vendor['input_sha256'] == candidate['input_sha256']
            trials = {'vendor': [], 'candidate': []}
            for trial in range(3):
                order = ['vendor', 'candidate'] if trial % 2 == 0 else ['candidate', 'vendor']
                for name in order:
                    timed = workers[name].request(dict(action='bench', m=m, rep=args.rep))
                    trials[name].append(timed['latency_ms'])
            times = {name: statistics.median(values) for name, values in trials.items()}
            row = dict(shape=shape['shape'], count=shape['count'], trials_ms=trials,
                       latency_ms=times, speedup=times['vendor']/times['candidate'],
                       errors=candidate['errors'], vendor_oracle_errors=vendor['oracle_errors'], input_sha256=candidate['input_sha256'], diagnostic=candidate['diagnostic'], numeric_passed=candidate['errors'][0]<.01 and candidate['errors'][1]<.02 and vendor['oracle_errors'][0]<.01 and vendor['oracle_errors'][1]<.02)
            if not row['numeric_passed']:
                row['diagnostic_speedup']=row['speedup']
                row['speedup']=None
                row['reason']='Fresh native/candidate numerical check failed; see oracle errors and saved tensors.'
            rows.append(row)
            output.write_text(json.dumps(result, indent=2) + '\n')
            print(precision, m, times, row['speedup'], flush=True)
        finished.set()
        monitor.join(timeout=12)
        assert pids() == owned
        monitor_log.write(json.dumps(dict(completed=True, time=time.time())) + '\n')
        for worker in workers.values():
            worker.process.stdin.write('{"action":"quit"}\n')
            worker.process.stdin.flush()
            assert worker.process.wait(timeout=30) == 0
    finally:
        finished.set()
        if monitor is not None:
            monitor.join(timeout=12)
        for pid in job_pids():
            os.kill(int(pid), signal.SIGTERM)
        for worker in workers.values():
            worker.log.close()
        monitor_log.close()
result['completed'] = True
output.write_text(json.dumps(result, indent=2) + '\n')
